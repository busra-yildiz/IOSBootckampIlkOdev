import UIKit

var ilce : String = "Yenimahalle"
print ("İlçe : \(ilce)")

var kitaAdi : String = "Asya"
print ("Kıta Adı : \(kitaAdi)")

var faksNumarasi : Int = 1995
print ("Faks Numarası : \(faksNumarasi)")

var postaKodu = 06000
print ("Ankara Posta Kodu : \(postaKodu)")

var instaAdresi : String = "catlakmuhendis28"
print ("Instagram Adresi : \(instaAdresi)")

var calistiginBolum : String = "İOS Developer"
print ("Çalıştığın Bölüm : \(calistiginBolum)")

var urunMiktari = 155
print ("Ürün Miktarı : \(urunMiktari)")

var musteriSoyadi : String = "Toprak"
print ("Müşteri Soyadı : \(musteriSoyadi)")

var odemeMiktari = 750
print ("Ödeme Miktarı : \(odemeMiktari) TL")

var dogumTarihi : String = "27 Ocak 1995"
print ("Doğum Tarihi : \(dogumTarihi)")

var borc = 2000
print ("Borç Tutarı : \(borc) TL")

var medeniHal : String = "Bekar"
print ("Medeni Hal : \(medeniHal)")


var video_Yorumu : String = "Gerçekten Çok Güzel Olmuş"
print ("Video Yorumu : \(video_Yorumu)")

var odemeSaati : Double = 15.00
print ("Ödeme Saati : \(odemeSaati)")

var eftMiktari = 900
print ("Eft Miktarı : \(eftMiktari) TL")

var satilanMiktar = 200
print ("Satılan Miktar : \(satilanMiktar)")

var telefonModeli : String = "Note 10 Pro"
print ("Telefon Modeli : \(telefonModeli)")

var dergiAdi : String = "Kadınca"
print ("Dergi Adı : \(dergiAdi)")

var basimTarihi : String = "1 Aralık 1969"
print ("Basım Tarihi : \(basimTarihi)")

var zamMiktari : String = "Yüzde 12.5"
print ("Zam Miktarı : \(zamMiktari)")

var daireSayisi = 38
print ("Daire Sayısı : \(daireSayisi)")

var enlem : String = "30 Kelvin"
print ("Enlem : \(enlem) Derece")

var boylam : String = "29 derece 5 dakika 70 saniye"
print ("Boylam : \(boylam)")

var yemekAdi : String = "İmam Bayıldı"
print ("Yemek Adı : \(yemekAdi)")

var urunFiyati = 35500
print ("Ürün Fiyatı : \(urunFiyati) TL")

var sirket : String = "Yazılım"
print ("Şirket Türü : \(sirket)")

var videoAdi : String = "Konuşanlar"
print ("Video Adı : \(videoAdi)")

var muzikSuresi = 3
print ("Müzik Süresi : \(muzikSuresi)")

var mekanPuani = 2
print ("Mekan Puanı : \(mekanPuani)")

var dosyaAdi : String = "İOS Bootcamp Klasörü"
print ("Dosya Adı : \(dosyaAdi)")

var resimFormati : String = "jpg"
print ("Resim Formatı : \(resimFormati)")

var renk : String = "Pembe"
print ("Renk : \(renk)")

var renkKodu = 758856
print ("Renk Kodu : \(renkKodu)")

var bilgisayarModeli : String = "Macbook Pro"
print ("Bilgisayar Modeli : \(bilgisayarModeli)")

var ekranBoyutu :Double = 13.3
print ("Ekran Boyutu : \(ekranBoyutu) İnc")

var kullanimSuresi = 3
print ("Kullanım Süresi : \(kullanimSuresi) Yıl")

var basinc : Double = 17.6
print ("Basınç : \(basinc)")

var etkinlikGunu : String = "15 Eylül"
print ("Etkinlik Günü : \(etkinlikGunu)")

var odemeGunu : String = "Pazartesi"
print ("Ödeme Günü : \(odemeGunu)")

var yolculukCikisTarihi : String = "10 Şubat"
print ("Yolculuk Çıkış Tarihi : \(yolculukCikisTarihi)")

var mahalleAdi : String = "Demetevler"
print ("Mahalle Adı : \(mahalleAdi)")

var otobusHatti : String = "Ankara - İzmir"
print ("Otobüs Hattı : \(otobusHatti)")

var kullanilanDakika = 758
print ("Kullanılan Dakika : \(kullanilanDakika)")

var kargoTakipNo = 1234567
print ("Kargo Takip No : \(kargoTakipNo)")

var kuponSuresi : String = "1 Hafta"
print ("Kupon Süresi : \(kuponSuresi)")

var kuponKodu = 23456789
print ("Kupon Kodu : \(kuponKodu)")

var faturaTarihi : String = "15 Eylül"
print ("Fatura Tarihi : \(faturaTarihi)")


